package org.lsmr.selfcheckout.software;

import java.math.BigDecimal;
import java.util.List;

import org.lsmr.selfcheckout.Banknote;
import org.lsmr.selfcheckout.devices.AbstractDevice;
import org.lsmr.selfcheckout.devices.BanknoteDispenser;
import org.lsmr.selfcheckout.devices.BanknoteStorageUnit;
import org.lsmr.selfcheckout.devices.DisabledException;
import org.lsmr.selfcheckout.devices.EmptyException;
import org.lsmr.selfcheckout.devices.OverloadException;
import org.lsmr.selfcheckout.devices.SelfCheckoutStation;
import org.lsmr.selfcheckout.devices.SimulationException;
import org.lsmr.selfcheckout.devices.observers.AbstractDeviceObserver;
import org.lsmr.selfcheckout.devices.observers.BanknoteDispenserObserver;

public class BanknoteDispenserObserverLogic implements BanknoteDispenserObserver{	
	
private SCS_Logic scsLogic;
	
	public BanknoteDispenserObserverLogic (SCS_Logic scsL) {
		scsLogic = scsL;
	}
	
	@Override
	public void enabled(AbstractDevice<? extends AbstractDeviceObserver> device) {
		
	}

	@Override
	public void disabled(AbstractDevice<? extends AbstractDeviceObserver> device) {
		
	}

	@Override
	public void moneyFull(BanknoteDispenser dispenser){ //empty dispenser into storage when full
		// the devices themselves should already handle this.
		
	}

	
	@Override
	public void banknotesEmpty(BanknoteDispenser dispenser) {
		//System.out.print("Banknote dispenser is empty");
	}

	@Override
	public void billAdded(BanknoteDispenser dispenser, Banknote banknote) {
		//scsLogic.addAvailableFunds(value);
	}

	@Override
	public void banknoteRemoved(BanknoteDispenser dispenser, Banknote banknote) {
		//scsLogic.subtractAvailableFundsBnote(BigDecimal.valueOf(banknote.getValue()));
		//System.out.print("Banknote " + banknote.getValue() + " was removed from dispenser");
	}

	@Override
	public void banknotesLoaded(BanknoteDispenser dispenser, Banknote... banknotes) {
	}

	@Override
	public void banknotesUnloaded(BanknoteDispenser dispenser, Banknote... banknotes) {
	}
	
}
