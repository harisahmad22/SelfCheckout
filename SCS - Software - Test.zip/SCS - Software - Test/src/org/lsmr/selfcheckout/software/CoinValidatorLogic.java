package org.lsmr.selfcheckout.software;

import java.math.BigDecimal;

import org.lsmr.selfcheckout.Coin;
import org.lsmr.selfcheckout.devices.AbstractDevice;
import org.lsmr.selfcheckout.devices.CoinDispenser;
import org.lsmr.selfcheckout.devices.CoinValidator;
import org.lsmr.selfcheckout.devices.observers.AbstractDeviceObserver;
import org.lsmr.selfcheckout.devices.observers.CoinValidatorObserver;

public class CoinValidatorLogic implements CoinValidatorObserver{

	private SCS_Logic scsLogic;
	
	private boolean validCoinDetected = false;
	private boolean invalidCoinDetected = false;
	
	
	// Mainly made so that it connects with logic class.
	public CoinValidatorLogic (SCS_Logic scsL){
		scsLogic = scsL;
	}
	
	// Implement Invalid State Exception
	public void resetValidCoin() {
		if(validCoinDetected)
			validCoinDetected = false;
		else {
			//throw new Exception("ValidCoinDetected should not be going from False to False");
			System.out.println("ValidCoinDetected should not be going from False to False");
		}
	}
	
	public void resetInvalidCoin() {
		if(invalidCoinDetected)
			invalidCoinDetected = false;
		else {
			System.out.println("InvalidCoinDetected should not be going from False to False");
		}
	}
	
	//THE OVERRIDE METHODS.

	@Override
	public void enabled(AbstractDevice<? extends AbstractDeviceObserver> device) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void disabled(AbstractDevice<? extends AbstractDeviceObserver> device) {
		// TODO Auto-generated method stub
		
	}
	
	@Override
	public void validCoinDetected(CoinValidator validator, BigDecimal value) {
		
		// we cannot do this right away...
		// we also need to get notified from either the Dispenser(for this denomination of coin) or the StorageUnit
		// that they have had a coin added to them.
		// If neither of those get a notification, then the only other channel left is the tray.
			// it would only go here if both the dispenser and storage unit are full.
		
		
		// In all cases we will have two notifications that we need:
		// CoinValid && Dispenser accepted
		// CoinValid && StorageUnit accepted
		// InvalidCoin && Tray Accepted
		// what if we push to SCS_Logic that
		
		
		// Before I call this, I have to check whether coinAdded(CoinDispenser dispenser, Coin coin)
		// was called in the ConcreteObserver for CoinDispenserObserver.
		
		// There is a bug in his Hardware code. When the dispenser is full, he never bothers to send it to
		// storage unit.
		// It goes straight to the Tray.  
		// So for now that would leave us with 3 cases:
		/*
		 * CoinValid && Dispenser accepted
		 * 		  -> only with coin added from CoinDispenser
		 * CoinValid && Dispenser was full -> Coin passed to Tray {notified via coinAdded()}
		 * 		-> coinAdded
		 * 
		 * 
		 * CoinInvalid && Tray accepted (via coinAdded())  -> this is for the next void method.
		 *  // we wont be adding that value anyways.
		 */
		
		
		// Change the flag
		//validCoinDetected = true;
		
		// Send it to SCS_Logic.
		
		// reset it. 
		// validCoinDetected will go from true to false.
		// resetValidCoin();
		
		//scsLogic.addAvailableFundsCoins(value);
		
		
		 // CoinValid && Dispenser was full -> Coin passed to Tray {notified via coinAdded()}
		 // CoinInvalid && Tray accepted (via coinAdded())  -> this is for the next void method.
		 
		
		//scsLogic.addAvailableFundsCoins(value);
		
	}

	@Override
	public void invalidCoinDetected(CoinValidator validator) {
		/// CoinInvalid && Tray accepted (via coinAdded())
		
		// pass a message to SCS_Logic() & wait for the other notification from the other observer.
		//invalidCoinDetected = true;
		
		
		
		//resetInvalidCoin();

	}

}
