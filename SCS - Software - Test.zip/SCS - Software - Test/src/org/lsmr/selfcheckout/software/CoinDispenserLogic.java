package org.lsmr.selfcheckout.software;

import java.util.List;

import org.lsmr.selfcheckout.Coin;
import org.lsmr.selfcheckout.devices.AbstractDevice;
import org.lsmr.selfcheckout.devices.CoinDispenser;
import org.lsmr.selfcheckout.devices.CoinStorageUnit;
import org.lsmr.selfcheckout.devices.SimulationException;
import org.lsmr.selfcheckout.devices.observers.AbstractDeviceObserver;
import org.lsmr.selfcheckout.devices.observers.CoinDispenserObserver;

public class CoinDispenserLogic implements CoinDispenserObserver{

	private SCS_Logic scsLogic;
	
	public CoinDispenserLogic (SCS_Logic scsL) {
		scsLogic = scsL;
	}
	
	// These are from Abstract Device Observer.
	// Indicates that the device being passed has been enabled.
	@Override
	public void enabled(AbstractDevice<? extends AbstractDeviceObserver> device) {
		
	}
	
	// These are from Abstract Device Observer.
	@Override
	public void disabled(AbstractDevice<? extends AbstractDeviceObserver> device) {}

	@Override
	public void coinsFull(CoinDispenser dispenser) {
		if(scsLogic.getSCS().coinStorage.hasSpace()) { 
            try { 
                List<Coin> cn = dispenser.unload();
                for(Coin c : cn){
                    scsLogic.getSCS().coinStorage.accept(c); 
                    } 
                }
            catch(Exception e) { e.printStackTrace(); }
        } 
        else { throw new SimulationException(new
        IllegalStateException("Storage does not have space")); }
	}

	@Override
	public void coinsEmpty(CoinDispenser dispenser) {
		// Dispense is empty so I want to replenish it by using coins from
		// the Storage Unit?
	}

	@Override
	public void coinAdded(CoinDispenser dispenser, Coin coin) {
		// Valid coin would have been already checked at this point.
		scsLogic.addAvailableFunds(coin.getValue());
	}

	// A coin is removed from the Dispenser.
	// coin went to the tray?
	@Override
	public void coinRemoved(CoinDispenser dispenser, Coin coin) {
		
	}

	// This would mainly be used by a technician.
	@Override
	public void coinsLoaded(CoinDispenser dispenser, Coin... coins) {
		
	}

	@Override
	public void coinsUnloaded(CoinDispenser dispenser, Coin... coins) {
		
	}
	
	public SCS_Logic getSCS() {
		return scsLogic;
	}
		
}
