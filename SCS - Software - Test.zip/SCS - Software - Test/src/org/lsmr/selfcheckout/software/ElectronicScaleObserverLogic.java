package org.lsmr.selfcheckout.software;

import org.lsmr.selfcheckout.devices.AbstractDevice;
import org.lsmr.selfcheckout.devices.ElectronicScale;
import org.lsmr.selfcheckout.devices.SelfCheckoutStation;
import org.lsmr.selfcheckout.devices.observers.AbstractDeviceObserver;
import org.lsmr.selfcheckout.devices.observers.ElectronicScaleObserver;


public class ElectronicScaleObserverLogic implements ElectronicScaleObserver {

	private double currentWeight = 0.0;
	
	@Override
	public void enabled(AbstractDevice<? extends AbstractDeviceObserver> device) {}

	@Override
	public void disabled(AbstractDevice<? extends AbstractDeviceObserver> device) {}
	
	/**
	 * Announces that the weight on the indicated scale has changed.
	 * 
	 * @param scale
	 *            The scale where the event occurred.
	 * @param weightInGrams
	 *            The new weight.
	 */ // from ElectronicScaleObserver
	@Override
	public void weightChanged(ElectronicScale scale, double weightInGrams) {
		
		currentWeight += weightInGrams;
		
	}
	
	/**
	 * Announces that excessive weight has been placed on the indicated scale.
	 * 
	 * @param scale
	 *            The scale where the event occurred.
	 */	// from ElectronicScaleObserver
	@Override
	public void overload(ElectronicScale scale) {

		// the scale is disabled from receiving input and producing output
		scale.disable();
	}
	
	/**
	 * Announces that the former excessive weight has been removed from the
	 * indicated scale, and it is again able to measure weight.
	 * 
	 * @param scale
	 *            The scale where the event occurred.
	 */ // from ElectronicScaleObserver
	@Override
	public void outOfOverload(ElectronicScale scale) {
		
		scale.enable();
	}
	
	public double getCurrentWeight() {
		return currentWeight;
	}

	
	
}