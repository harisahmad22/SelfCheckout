package org.lsmr.selfcheckout.software;

import java.math.BigDecimal;
import java.util.HashMap;

import org.lsmr.selfcheckout.Barcode;
import org.lsmr.selfcheckout.devices.AbstractDevice;
import org.lsmr.selfcheckout.devices.BarcodeScanner;
import org.lsmr.selfcheckout.devices.observers.AbstractDeviceObserver;
import org.lsmr.selfcheckout.devices.observers.BarcodeScannerObserver;

public class BarCodeReader implements BarcodeScannerObserver {
    private boolean enable;
    private Barcode recentScan;
    private SCS_Logic scsLogic;
    private HashMap<Barcode,BigDecimal> shoppingCart;

    public BarCodeReader(SCS_Logic scs) {
    	scsLogic = scs;
    }
    
    @Override
    public void enabled(AbstractDevice<? extends AbstractDeviceObserver> device) {
        //System.out.println("The BarCodeReader is enabled");
        enable = true;
    }
    
    @Override
    public void disabled(AbstractDevice<? extends AbstractDeviceObserver> device) {
        //System.out.println("The BarCodeReader is disabled");
        enable = false;
    }
    
    @Override
    public void barcodeScanned(BarcodeScanner barcodeScanner, Barcode barcode) {
        if (enable) {
            System.out.println("The BarCodeReader scanned" + barcode.toString());
            recentScan = barcode;
            // After an item is scanned, it's expected to move that item to the bagging area
            shoppingCart.put(barcode, scsLogic.getDB().price(barcode));
        }
    }
    public Barcode mostRecent() {
        return recentScan;
    }
    
    public HashMap<Barcode,BigDecimal > getShoppingCart(){	
    	return shoppingCart;
    }
    
}