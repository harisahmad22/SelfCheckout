package org.lsmr.selfcheckout.software;

import java.math.BigDecimal;

import org.lsmr.selfcheckout.devices.AbstractDevice;
import org.lsmr.selfcheckout.devices.CoinSlot;
import org.lsmr.selfcheckout.devices.CoinValidator;
import org.lsmr.selfcheckout.devices.observers.AbstractDeviceObserver;
import org.lsmr.selfcheckout.devices.observers.CoinSlotObserver;
import org.lsmr.selfcheckout.devices.observers.CoinValidatorObserver;

public class CoinSlotLogic implements CoinSlotObserver {

	private SCS_Logic scsLogic;
	
	public CoinSlotLogic (SCS_Logic scsL) {
		this.scsLogic = scsL;
	}
	
	@Override
	public void enabled(AbstractDevice<? extends AbstractDeviceObserver> device) {}

	@Override
	public void disabled(AbstractDevice<? extends AbstractDeviceObserver> device) {	}

	@Override
	public void coinInserted(CoinSlot slot) {
		
		// First thing would be to check if it's validated.
		
		// There are 3 interconnections:
		
		
		// slot to validator  -- 
		
		// the 3 channels being passed to coinValidator
		// The coinValidator has 3 similar channels channels
			// (rejectChannel, dispenser, overflow)
			// which it use
		
		// dispenser to tray --
		
	}

	

}
