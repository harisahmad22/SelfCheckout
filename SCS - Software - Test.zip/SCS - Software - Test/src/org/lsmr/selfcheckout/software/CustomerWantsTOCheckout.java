package org.lsmr.selfcheckout.software;

import java.math.BigDecimal;

import org.lsmr.selfcheckout.devices.BanknoteDispenser;
import org.lsmr.selfcheckout.devices.CoinDispenser;
import org.lsmr.selfcheckout.devices.SelfCheckoutStation;

public class CustomerWantsTOCheckout{
	
	private SCS_Logic scsLogic;

	public void CustomerWantsTOCheckout(SCS_Logic scsL){
		
		scsLogic = scsL;
		scsLogic.setAvailableFunds(BigDecimal.ZERO);
		
		// disabling the scanner and scale since the customer wont be using them anymore 
		scsLogic.getSCS().scanner.disable();  //scs.scanner.disable();
		scsLogic.getSCS().scale.disable();// scs.scale.disable();
		
		// enabling the coin Validator/tray/and slot so the customer could pay with coins
		scsLogic.getSCS().coinValidator.enable();
		scsLogic.getSCS().coinSlot.enable();
		scsLogic.getSCS().coinTray.enable();
		scsLogic.getSCS().coinStorage.enable();
		for(CoinDispenser cDispenser : scsLogic.getSCS().coinDispensers.values()) {
			cDispenser.enable();
		}
		
		// enabling the banknote Validator/input/and output so the customer could pay with coins
		scsLogic.getSCS().banknoteValidator.enable();
		scsLogic.getSCS().banknoteInput.enable();
		scsLogic.getSCS().banknoteOutput.enable();
		scsLogic.getSCS().banknoteStorage.enable();
		
		for(BanknoteDispenser bd : scsLogic.getSCS().banknoteDispensers.values()) {
			bd.enable();
		}
	}
	
	public SCS_Logic getSCS() {
		return scsLogic;
	}
}