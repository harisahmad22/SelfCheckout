package org.lsmr.selfcheckout.software;

import org.lsmr.selfcheckout.devices.AbstractDevice;
import org.lsmr.selfcheckout.devices.CoinTray;
import org.lsmr.selfcheckout.devices.observers.AbstractDeviceObserver;
import org.lsmr.selfcheckout.devices.observers.CoinTrayObserver;

public class CoinTrayLogic implements CoinTrayObserver{

	private SCS_Logic scsLogic;
	
	public CoinTrayLogic (SCS_Logic scsL) {
		scsLogic = scsL;
	}
	
	@Override
	public void enabled(AbstractDevice<? extends AbstractDeviceObserver> device) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void disabled(AbstractDevice<? extends AbstractDeviceObserver> device) {
		// TODO Auto-generated method stub
		
	}

	/**
	 * Announces that a coin has been added to the indicated tray.
	 * 
	 * @param tray
	 *            The tray where the event occurred.
	 */
	@Override
	public void coinAdded(CoinTray tray) {
		// TODO Auto-generated method stub
		
	}

}
