package org.lsmr.selfcheckout.software;

import java.math.BigDecimal;
import java.util.ArrayList;

import org.lsmr.selfcheckout.Barcode;
import org.lsmr.selfcheckout.BarcodedItem;
import org.lsmr.selfcheckout.Numeral;
import org.lsmr.selfcheckout.products.BarcodedProduct;

final class ItemPrice {
    private BarcodedItem item;
    private BarcodedProduct product_bc;
    public ItemPrice (BarcodedItem item, BarcodedProduct product_bc) {
        this.item = item;
        this.product_bc = product_bc;
    }
    public BigDecimal getPrice() {
        return product_bc.getPrice();
    }
    public Barcode getBarcode() {
        return item.getBarcode();
    }
    public double getWeight() {
        return item.getWeight();
    }
}

public class FakeDataBase {
	
	ArrayList<ItemPrice> db = new ArrayList<ItemPrice>();
    
    public void attach(BarcodedItem item, BarcodedProduct product) {
        db.add(new ItemPrice(item, product));
    }

    public BigDecimal price(Barcode barcode) {
        for (int i=0; i<db.size(); i++) {
            if (barcode.equals(db.get(i).getBarcode())) {
                return db.get(i).getPrice();
            }
        }
        BigDecimal error = new BigDecimal(-1.0);
        return error;
    }

    public double weight(Barcode barcode) {
        for (int i=0; i<db.size(); i++) {
            if (barcode.equals(db.get(i).getBarcode())) {
                return db.get(i).getWeight();
            }
        }
        return -1.0;
    }
    
    public ArrayList<ItemPrice> getDB() {
    	return db;
    }
}