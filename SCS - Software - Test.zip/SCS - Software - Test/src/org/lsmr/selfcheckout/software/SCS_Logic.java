package org.lsmr.selfcheckout.software;

import java.math.BigDecimal;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

import org.lsmr.selfcheckout.Barcode;
import org.lsmr.selfcheckout.devices.CoinSlot;
import org.lsmr.selfcheckout.devices.SelfCheckoutStation;
import org.lsmr.selfcheckout.devices.SimulationException;
import org.lsmr.selfcheckout.software.BarCodeReader;

public class SCS_Logic  {
		
	// Banknote Concrete Observers
	// public BanknoteStorageUnitObserverLogic bStrUnitLogic;
	// public BanknoteValidatorObserverLogic bValidatorLogic;
	
	// other variables
	/*
	 * private BigDecimal availableFundsCoins = BigDecimal.ZERO; private int
	 * availableFundsBnotes = 0; // could this cause an error?
	 */	
	// we are going to have to combine BigDecimal with int. 
	private BigDecimal totalFunds = BigDecimal.ZERO;
	private SelfCheckoutStation aSCS;
	
	BigDecimal total = new BigDecimal(0.0);
	BarCodeReader barcodeReaderObserver;
	FakeDataBase db = new FakeDataBase();
	BigDecimal changeForCustomer = BigDecimal.ZERO;

	
	// CONSTRUCTOR FOR SELF CHECKOUT LOGIC.
		public SCS_Logic(SelfCheckoutStation scs) {
			
			BarCodeReader barcodeReaderObserver = new BarCodeReader(this);
			
			aSCS = scs;
					
			// Initializing CONCRETE OBSERVERS for Coin
			CoinDispenserLogic cDispenserLogic = new CoinDispenserLogic(this);
			CoinSlotLogic cSlotLogic = new CoinSlotLogic(this);
			CoinStorageUnitLogic cStrUnitLogic = new CoinStorageUnitLogic(this);
			CoinTrayLogic cTrayLogic = new CoinTrayLogic(this);
			CoinValidatorLogic cValidatorLogic = new CoinValidatorLogic(this);
			
			
			// Initializing CONCRETE OBSERVERS for BankNotes
			BanknoteDispenserObserverLogic bDispenserLogic = new BanknoteDispenserObserverLogic(this);
			BanknoteSlotObseverLogic bSlotLogic = new BanknoteSlotObseverLogic(this);
			BanknoteStorageUnitObserverLogic bStrUnitLogic = new BanknoteStorageUnitObserverLogic(this);
			BanknoteValidatorObserverLogic bValidatorLogic = new BanknoteValidatorObserverLogic(this);
			
			// The device in the SCS is not attached to the CONCRETE observers.
			// Attaching all coin related devices to the CONCRETE observers.
			// don't need to worry about coin slot right now
			aSCS.coinSlot.attach(cSlotLogic); 
			aSCS.coinValidator.attach(cValidatorLogic);
			aSCS.coinStorage.attach(cStrUnitLogic);
			aSCS.coinTray.attach(cTrayLogic);
			
			// banknote related devices from the self checkout station.
			// Attaching them to their respective "Concrete Observers"
			aSCS.banknoteValidator.attach(bValidatorLogic);
			aSCS.banknoteStorage.attach(bStrUnitLogic);
			aSCS.banknoteInput.attach(bSlotLogic);
			aSCS.banknoteOutput.attach(bSlotLogic);
			
			aSCS.scanner.attach(barcodeReaderObserver);
			
			// Attaching all the dispensers using Denomination size.
			for(int i = 0; i < aSCS.coinDenominations.size() ; i++ ) {
				
				// i want to access the value of the HashMap which contains the CoinDispensers.
				// aSCS.coinDenominations[i] was not working.
				// get the coin Dispenser.
				// I'm not sure if this is right. inside bracket, we get a denomination
				// from that we can get the dispenser, which we proceed to attach it.
				// Later on, there will be a dispenser channel for each denomination
				// the channel is between 
				aSCS.coinDispensers.get(aSCS.coinDenominations.get(i)).attach(cDispenserLogic);
				
			}
			
			// Banknote Dispensers - attaching
			for (int i = 0; i < aSCS.banknoteDenominations.length; i++ ) {		
				aSCS.banknoteDispensers.get(aSCS.banknoteDenominations[i]).attach(bDispenserLogic);	
			}
			
		}
		
		public void add_total() {
			total = total.add( db.price(barcodeReaderObserver.mostRecent()) );
		}
		
		// END OF CONSTRUCTOR FOR SELF-CHECKOUT LOGIC.
	
	public void makeCashPayment(BigDecimal billTotal) {
				// if (totalFunds > total) || (both values are equal)
				// Proceed to payment
				if((totalFunds.compareTo(total) == 1) || (totalFunds.compareTo(total) == 0)) {
					// we can add something about the change in here.
					// but don't to worry about the mechanism of 
					// providing change for now.
					BigDecimal change = totalFunds.subtract(total);
					
					// Proceed to Print receipt. Thank Customer.
					thankCustomer(change);
					
				
					// Resetting Funds for the next customer.
					setAvailableFunds(BigDecimal.ZERO);
				}
				else {
					// Some sort of exception when there's not enough funds.
					System.out.println("Not enough funds to pay bill");
				}
	}
		
		// Thank Customer for their Business
		// The receipt
		public void thankCustomer(BigDecimal change) {
			
			
			// from stackoverflow: https://stackoverflow.com/questions/1066589/iterate-through-a-hashmap
			/*
			 * for (Map.Entry<String, Object> entry : map.entrySet()) {
	    		String key = entry.getKey();
	    		Object value = entry.getValue();
	    	// ...
			}
			 */
			// Set<Map.Entry<K,V>>
			// for(HashMap<Barcode,BigDecimal> entry : (barcodeReaderObserver.getShoppingCart()).entrySet())
			// barcodeReaderObserver.getShoppingCart();
			
			Iterator<Entry<Barcode,BigDecimal>> receiptIterator = (barcodeReaderObserver.getShoppingCart()).entrySet().iterator();

			double grand_total = 0.0;
	        while(receiptIterator.hasNext()) {

	            Map.Entry<Barcode,BigDecimal> mapElement= (Map.Entry<Barcode,BigDecimal>)receiptIterator.next();
	            grand_total += mapElement.getValue().doubleValue();
	            System.out.println("Barcode: " + mapElement.getKey().toString() + " Price: " + mapElement.getValue().toString());

	        }
			
			System.out.println("Thank you for your Business");
			System.out.println("Your change is: "+ change);
			System.out.println("Your total is: " + grand_total);
			// You could perhaps iterate through the Fake Database and 
			// print out the barcoded items and so on.
			
		}
			
		
	// Methods in implementation
	// This will work for both banknotes and coins
	public void addAvailableFunds(BigDecimal a) {
		totalFunds = totalFunds.add(a);
		
	}
	
	public void addAvailableFunds(int a) {
		totalFunds = totalFunds.add(BigDecimal.valueOf(a));
		
	}
	
	// "a" in this case could be the cost of all items.
	public void subtractAvailableFunds(BigDecimal a) {
		if(totalFunds.compareTo(a) >= 0) {
			totalFunds = totalFunds.subtract(a);
		}
		else 
		{	// illegal operation exception.
			throw new SimulationException(new IllegalArgumentException
					("Tried to remove more funds than present in dispenser"));
		}
		
	}

	public void setAvailableFunds(BigDecimal a) {
		//
		if(a.compareTo(BigDecimal.ZERO) >= 0) {
			totalFunds = a;
		}		
	}
	
	public BigDecimal getTotalFunds() {
		BigDecimal result = totalFunds;
		return result;
	}
	
	public SelfCheckoutStation getSCS() {
		return aSCS;
	}
	
	public FakeDataBase getDB() {
		return db;
	}
	
	public BigDecimal getTotal() 
	{
		return total;
	}
	
	public BarCodeReader get_bRO() {
		return barcodeReaderObserver;
	}
	
}
