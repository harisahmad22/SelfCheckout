package org.lsmr.selfcheckout.softwaretest;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Currency;
import java.util.Locale;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.lsmr.selfcheckout.Barcode;
import org.lsmr.selfcheckout.BarcodedItem;
import org.lsmr.selfcheckout.Coin;
import org.lsmr.selfcheckout.Numeral;
import org.lsmr.selfcheckout.devices.AbstractDevice;
import org.lsmr.selfcheckout.devices.BanknoteStorageUnit;
import org.lsmr.selfcheckout.devices.BanknoteValidator;
import org.lsmr.selfcheckout.devices.BarcodeScanner;
import org.lsmr.selfcheckout.devices.observers.BarcodeScannerObserver;
import org.lsmr.selfcheckout.devices.CoinDispenser;
import org.lsmr.selfcheckout.devices.CoinStorageUnit;
import org.lsmr.selfcheckout.devices.ElectronicScale;
import org.lsmr.selfcheckout.devices.SelfCheckoutStation;
import org.lsmr.selfcheckout.devices.SimulationException;
import org.lsmr.selfcheckout.devices.observers.AbstractDeviceObserver;
import org.lsmr.selfcheckout.devices.observers.BanknoteStorageUnitObserver;
import org.lsmr.selfcheckout.devices.observers.BarcodeScannerObserver;
import org.lsmr.selfcheckout.devices.observers.CoinStorageUnitObserver;
import org.lsmr.selfcheckout.products.BarcodedProduct;
import org.lsmr.selfcheckout.software.ElectronicScaleObserverLogic;
import org.lsmr.selfcheckout.software.FakeDataBase;

import org.lsmr.selfcheckout.software.SCS_Logic;
import org.lsmr.selfcheckout.software.BanknoteStorageUnitObserverLogic;
import org.lsmr.selfcheckout.software.BanknoteValidatorObserverLogic;
import org.lsmr.selfcheckout.software.BarCodeReader;
import org.lsmr.selfcheckout.software.CoinDispenserLogic;
import org.lsmr.selfcheckout.software.CoinStorageUnitLogic;
import org.lsmr.selfcheckout.software.CustomerWantsTOCheckout;

public class SCS_Test_Suite_1 {
		
	private ElectronicScaleObserverLogic scale_subject;
	private ElectronicScale scale;
	
	private SelfCheckoutStation station;
	private SCS_Logic scs_subject;
	
	private CustomerWantsTOCheckout checkout_subject;
	
	private int[] banknotes;
	private BigDecimal[] coins;
	
	private CoinDispenserLogic coin_subject;
	private CoinDispenser dispenser_subject;
	private Coin coin;
	private CoinStorageUnitLogic storage_subject;
	private CoinStorageUnit unit_subject;
	
	private int found;
	
	private BanknoteStorageUnitObserverLogic bstorage_subject;
	private BanknoteStorageUnit bunit_subject;
	private BanknoteValidatorObserverLogic validator_obs_subject;
	private BanknoteValidator validator_subject;
	
	private BarCodeReader reader_subject;
	private BarcodeScanner scanner_subject;
	private Barcode barcode_subject;
	private Barcode barcode_fail_subject;
	
	private Numeral[] nums;
	private Numeral[] nums1;
	
	private FakeDataBase fake_subject;
	private BarcodedItem bItem;
	private BarcodedProduct bProduct;
	
	private BarcodedItem cItem;

	@Before
	public void setUp() throws Exception {
		scale_subject = new ElectronicScaleObserverLogic();
		scale = new ElectronicScale(50, 2);
		scale.endConfigurationPhase();
		
		banknotes = new int[]{5, 10, 20, 50, 100};
		coins = new BigDecimal[] {new BigDecimal("0.05"), new BigDecimal("0.10"), new BigDecimal("0.25")};
		
		station = new SelfCheckoutStation(Currency.getInstance(Locale.CANADA), banknotes, coins, 50, 2);
		scs_subject = new SCS_Logic(station);
		
		checkout_subject = new CustomerWantsTOCheckout();
		
		coin_subject = new CoinDispenserLogic(scs_subject);
		dispenser_subject = new CoinDispenser(50);
		coin = new Coin(Currency.getInstance(Locale.CANADA), new BigDecimal("0.05"));
		storage_subject = new CoinStorageUnitLogic(scs_subject);
		unit_subject = new CoinStorageUnit(50);
		
		found = 0;
		
		bstorage_subject = new BanknoteStorageUnitObserverLogic(scs_subject);
		bunit_subject = new BanknoteStorageUnit(50);
		validator_obs_subject = new BanknoteValidatorObserverLogic(scs_subject);
		validator_subject = new BanknoteValidator(Currency.getInstance(Locale.CANADA), banknotes);
		
		reader_subject = new BarCodeReader(scs_subject);
		scanner_subject = new BarcodeScanner();
		
		nums = new Numeral[] {Numeral.one, Numeral.two, Numeral.three, Numeral.four, Numeral.five};
		nums1 = new Numeral[] {Numeral.nine, Numeral.two, Numeral.eight, Numeral.four, Numeral.seven};
		barcode_subject = new Barcode(nums);
		barcode_fail_subject = new Barcode(nums1);
		
		fake_subject = new FakeDataBase();
		bItem = new BarcodedItem(barcode_subject, 50.00);
		cItem = new BarcodedItem(barcode_subject, 50.00);
		bProduct = new BarcodedProduct(barcode_subject, "apple", new BigDecimal("2.00"));
	}
	

	@After
	public void tearDown() throws Exception {
	}

	//test weightChanged in ElectronicScaleObserverLogic
	@Test
	public void testWeightChanged() {
		scale_subject.weightChanged(scale, 50);
		assertEquals(scale_subject.getCurrentWeight(), 50, 0.001);
	}
	
	//test overload in ElectronicScaleObserverLogic
	@Test
	public void testOverload() {
		scale_subject.overload(scale);
		assertTrue(scale.isDisabled());
	}
	
	//test outOfOverload in ElectronicScaleObserverLogic
	@Test
	public void testOutOfOverload() {
		scale_subject.outOfOverload(scale);
		assertFalse(scale.isDisabled());
	}
	
	//test customerWantsToCheckOut
	//test fails
	@Test
	public void testCheckout() {
		checkout_subject.CustomerWantsTOCheckout(scs_subject);
		
		assertEquals(checkout_subject.getSCS().getTotalFunds(), new BigDecimal("0"));
		
		assertTrue(station.scanner.isDisabled());
		assertTrue(station.scale.isDisabled());
		
		assertFalse(station.coinValidator.isDisabled());
		assertFalse(station.coinSlot.isDisabled());
		assertFalse(station.coinTray.isDisabled());
		
		assertFalse(station.banknoteValidator.isDisabled());
		assertFalse(station.banknoteInput.isDisabled());
		assertFalse(station.banknoteOutput.isDisabled());
		
	}
	
	//test coinAdded in CoinDispenserLogic
	//test fails- something to do with adding with BigDecimal I think
	@Test
	public void testCoinAdded() {
		coin_subject.coinAdded(dispenser_subject, coin);
		assertEquals(coin_subject.getSCS().getTotalFunds(), new BigDecimal("0.05"));
	}
	
	//test coinsFull in CoinStorageUnitLogic
	//how can we test for the array that unload returns?
	@Test
	public void testCoinsFull() {
		unit_subject.attach(new CoinStorageUnitObserver() {
			
			@Override
			public void enabled(AbstractDevice<? extends AbstractDeviceObserver> device) {
				fail();
			}

			@Override
			public void disabled(AbstractDevice<? extends AbstractDeviceObserver> device) {
				fail();
			}
		
			@Override
			public void coinsFull(CoinStorageUnit unit) {
				fail();
			}
			
			@Override
			public void coinAdded(CoinStorageUnit unit) {
				fail();
			}

			public void coinsLoaded(CoinStorageUnit unit) {
				fail();
			}

			public void coinsUnloaded(CoinStorageUnit unit) {
				found += 1;
			}
		});

		storage_subject.coinsFull(unit_subject);
		assertEquals(found, 1);
		
	}
	
	//test banknotesFull in BanknoteStorageUnitLogic
	//how can we test for the array that unload returns?
	@Test
	public void testBanknotesFull() {
		bunit_subject.attach(new BanknoteStorageUnitObserver() {
			
			@Override
			public void enabled(AbstractDevice<? extends AbstractDeviceObserver> device) {
				fail();
			}

			@Override
			public void disabled(AbstractDevice<? extends AbstractDeviceObserver> device) {
				fail();
			}
		
			@Override
			public void banknotesFull(BanknoteStorageUnit unit) {
				fail();
			}
			
			@Override
			public void banknoteAdded(BanknoteStorageUnit unit) {
				fail();
			}

			public void banknotesLoaded(BanknoteStorageUnit unit) {
				fail();
			}
			
			public void banknotesUnloaded(BanknoteStorageUnit unit) {
				found += 1;
			}
		});

		bstorage_subject.banknotesFull(bunit_subject);
		assertEquals(found, 1);
	}
	
	//test validBanknoteDetected in BanknoteValidatorObserverLogic
	//test fails- I think it is also related to adding with BigDecimal
	@Test
	public void testvalidBanknoteDetected() {
		validator_obs_subject.validBanknoteDetected(validator_subject, Currency.getInstance(Locale.CANADA), 20);
		assertEquals(validator_obs_subject.getSCS().getTotalFunds(), new BigDecimal("20"));
	}
	
	//test barcodeScanned in BarCodeReader
	@Test
	public void testBarcodeScanned() {
		reader_subject.enabled(scanner_subject);
		reader_subject.barcodeScanned(scanner_subject, barcode_subject);
		assertEquals(reader_subject.mostRecent(), barcode_subject);
	}
	
	//test attach in FakeDataBase
	@Test
	public void testAttach() {
		fake_subject.attach(bItem, bProduct);
		assertEquals(fake_subject.getDB().size(), 1);
	}
	
	//test price in FakeDataBase
	@Test
	public void testPrice() {
		fake_subject.attach(bItem, bProduct);
		assertEquals(fake_subject.price(barcode_subject), new BigDecimal("2.00"));
	}
	
	//test price in FakeDataBase with no price found
	@Test
	public void testPriceFail() {
		fake_subject.attach(bItem, bProduct);
		assertEquals(fake_subject.price(barcode_fail_subject), new BigDecimal("-1"));
	}
	
	//test weight in FakeDataBase
	@Test
	public void testWeight() {
		fake_subject.attach(bItem, bProduct);
		assertEquals(fake_subject.weight(barcode_subject), 50.00, 0.001);
	}
		
	//test weight in FakeDataBase with no weight found
	@Test
	public void testWeightFail() {
		fake_subject.attach(bItem, bProduct);
		assertEquals(fake_subject.weight(barcode_fail_subject), -1, 0.001);
	}
	
	//test add_total in SCS_Logic
	@Test
	public void testAdd_Total() {
		scs_subject.getDB().attach(bItem, bProduct);
		scs_subject.getSCS().scanner.scan(cItem);
		scs_subject.add_total();
		assertEquals(scs_subject.getTotal(), new BigDecimal("2.00"));
	}
	
	//test BigDecimal addAvailableFunds in SCS_Logic
	@Test
	public void testBAddAvailableFunds() {
		scs_subject.addAvailableFunds(new BigDecimal(20.00));
		BigDecimal a = scs_subject.getTotalFunds();
		BigDecimal b = new BigDecimal(20.00);
		assertEquals(b, a);
	}
	
	//test int addAvailableFunds in SCS_Logic
	@Test
	public void testIAddAvailableFunds() {
		scs_subject.addAvailableFunds(20);
		assertEquals(scs_subject.getTotalFunds(), new BigDecimal("20"));
	}
	
	//first test subtractAvailableFunds in SCS_Logic
	@Test
	public void subtractAvailableFunds() {
		scs_subject.addAvailableFunds(new BigDecimal("20.00"));
		scs_subject.subtractAvailableFunds(new BigDecimal("15.00"));
		assertEquals(scs_subject.getTotalFunds(), new BigDecimal("5.00"));
	}
	
	//second test subtractAvailableFunds in SCS_Logic
	@Test(expected = SimulationException.class)
	public void subtractAvailableFunds2() {
		scs_subject.subtractAvailableFunds(new BigDecimal("15.00"));
	}
	
	//test setAvailableFunds in SCS_Logic 
	@Test
	public void setAvailableFunds() {
		scs_subject.setAvailableFunds(new BigDecimal("18.00"));
		assertEquals(scs_subject.getTotalFunds(), new BigDecimal("18.00"));
	}

}
